import streamlit as st
import psutil
from datetime import datetime, timedelta
import time
import json
import os
import requests
import pandas as pd
import sqlite3
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np
import statsmodels.tsa.arima.model as sm_arima

# Set Streamlit page config
st.set_page_config(page_title="PreBreak Monitor", layout="wide", initial_sidebar_state="expanded")

# --- Custom CSS for Dark Mode, Font and General Styling ---
# Using st.markdown with unsafe_allow_html=True to inject CSS
st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
    
    html, body, [class*="st-emotion"] {
        font-family: 'Inter', sans-serif;
    }

    /* Base app background color, controlled by CSS variable */
    .stApp {
        background-color: var(--app-bg-color); 
        color: var(--text-color); /* General text color for the app */
    }
    .stAlert {
        border-radius: 0.5rem; /* rounded-lg */
    }
    .stButton>button {
        border-radius: 0.5rem; /* rounded-lg */
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); /* shadow-md */
        transition: all 0.2s ease-in-out;
        background-color: #3b82f6; /* blue-500 */
        color: white;
        border: none;
        padding: 0.75rem 1.25rem;
        font-weight: 600;
    }
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* shadow-lg */
        background-color: #2563eb; /* blue-600 */
    }
    .stSlider > div > div > div {
        border-radius: 0.5rem; /* rounded-lg */
    }
    .stTextInput > div > div > input {
        border-radius: 0.5rem; /* rounded-lg */
    }
    .st-dg, .st-ck, .st-cn { /* Targets various input/select boxes */
        border-radius: 0.5rem; /* rounded-lg */
    }
    /* Styles for the metrics and containers */
    .st-au, .st-bf, .st-bg, .st-b5, .st-a8, .st-br { /* metric, text_area, columns, info, warning, error */
        border-radius: 0.5rem; /* rounded-lg */
        padding: 1rem; /* p-4 */
    }

    /* Common container/card styles, colors are controlled by CSS variables */
    .theme-container {
        border-radius: 0.75rem; /* rounded-xl */
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* shadow-lg */
        margin-bottom: 2rem; /* Add margin-bottom for better spacing between sections */
        background-color: var(--container-bg-color);
        color: var(--text-color);
    }
    .theme-card {
        border-radius: 0.75rem; /* rounded-xl */
        padding: 1rem; /* p-4 */
        margin-bottom: 1rem; /* mb-4 */
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); /* shadow-md */
        background-color: var(--card-bg-color);
        color: var(--text-color);
    }

    /* Specific styling for st.metric to look like a card */
    .st-au { /* Target the Streamlit metric container */
        background-color: var(--card-bg-color); /* Will be set dynamically by JS */
        border-radius: 0.75rem;
        padding: 1rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        margin-bottom: 1rem; /* Consistent spacing */
    }
    .st-bv { /* Target the value in st.metric */
        font-size: 2.25rem; /* text-4xl */
        font-weight: 700; /* font-bold */
    }
    .st-c1 { /* Target the label in st.metric */
        font-size: 0.875rem; /* text-sm */
        color: var(--sub-text-color); /* slate-400 */
        margin-bottom: 0.25rem;
    }

    /* Styling for st.text_area to look like a card */
    .stTextArea > label { /* Target the label of the text area */
        font-size: 1.125rem; /* text-lg */
        font-weight: 600;
        margin-bottom: 0.5rem;
        display: block; /* Make label a block element for spacing */
    }
    .stTextArea > div > div { /* Target the actual text area container */
        background-color: var(--card-bg-color);
        border-radius: 0.75rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        padding: 1rem;
        border: none; /* Remove default border */
    }
    .stTextArea > div > div > textarea { /* Target the textarea itself */
        background-color: transparent; /* Make inner textarea transparent */
        color: var(--text-color);
    }

    /* Styling for st.info, st.warning, st.error */
    .st-br { /* Streamlit's default container for info/warning/error */
        border-left: 6px solid var(--st-info-border-color); /* Streamlit's default color variables */
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        background-color: var(--card-bg-color); /* Match card background */
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        color: var(--text-color);
    }
    .st-br.st-cf { /* Info */
        --st-info-border-color: #3b82f6; /* blue-500 */
    }
    .st-br.st-ch { /* Warning */
        --st-info-border-color: #f59e0b; /* amber-500 */
    }
    .st-br.st-c9 { /* Error */
        --st-info-border-color: #ef4444; /* red-500 */
    }

    </style>
    <script>
    // Script to dynamically apply CSS variables for theme
    function applyThemeStyles() {
        const isDarkMode = document.body.classList.contains('dark-mode');
        if (isDarkMode) {
            document.documentElement.style.setProperty('--app-bg-color', '#0f172a'); /* Tailwind slate-900 */
            document.documentElement.style.setProperty('--container-bg-color', '#1a202c'); /* Deeper background for containers */
            document.documentElement.style.setProperty('--card-bg-color', '#2d3748');
            document.documentElement.style.setProperty('--text-color', '#e2e8f0');
            document.documentElement.style.setProperty('--sub-text-color', '#94a3b8');
            document.documentElement.style.setProperty('--st-info-border-color', '#3b82f6');
            document.documentElement.style.setProperty('--st-warning-border-color', '#f59e0b');
            document.documentElement.style.setProperty('--st-error-border-color', '#ef4444');
        } else {
            document.documentElement.style.setProperty('--app-bg-color', '#f1f5f9'); /* Tailwind slate-100 */
            document.documentElement.style.setProperty('--container-bg-color', '#f8fafc'); /* Tailwind slate-50 */
            document.documentElement.style.setProperty('--card-bg-color', '#ffffff');
            document.documentElement.style.setProperty('--text-color', '#1e293b');
            document.documentElement.style.setProperty('--sub-text-color', '#64748b');
            document.documentElement.style.setProperty('--st-info-border-color', '#3b82f6');
            document.documentElement.style.setProperty('--st-warning-border-color', '#f59e0b');
            document.documentElement.style.setProperty('--st-error-border-color', '#ef4444');
        }
    }

    // Observe changes to the body's class list
    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                applyThemeStyles();
            }
        }
    });

    // Start observing the body for class changes
    observer.observe(document.body, { attributes: true });

    // Apply styles on initial load
    applyThemeStyles();
    </script>
    """, unsafe_allow_html=True)


# --- Database Setup ---
DB_PATH = os.path.join(os.path.dirname(__file__), 'system_monitor.db')

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usage_data (
            timestamp TEXT PRIMARY KEY,
            cpu REAL,
            ram REAL,
            disk REAL,
            battery TEXT
        )
    ''')
    conn.commit()
    conn.close()
    print(f"DEBUG: SQLite database initialized at {DB_PATH}")

# Initialize DB when the script runs
init_db()

# --- Session State Initialization ---
if 'alert_log' not in st.session_state:
    st.session_state.alert_log = []
if 'alert_sent_cpu_threshold' not in st.session_state:
    st.session_state.alert_sent_cpu_threshold = False
if 'alert_sent_ram_threshold' not in st.session_state:
    st.session_state.alert_sent_ram_threshold = False
if 'alert_sent_disk_threshold' not in st.session_state:
    st.session_state.alert_sent_disk_threshold = False
if 'alert_sent_cpu_trend' not in st.session_state:
    st.session_state.alert_sent_cpu_trend = False
if 'alert_sent_ram_trend' not in st.session_state:
    st.session_state.alert_sent_ram_trend = False
if 'alert_sent_disk_trend' not in st.session_state: # FIXED: Was duplicated with ram_trend
    st.session_state.alert_sent_disk_trend = False 
if 'alert_sent_cpu_prediction' not in st.session_state:
    st.session_state.alert_sent_cpu_prediction = False
if 'alert_sent_ram_prediction' not in st.session_state:
    st.session_state.alert_sent_ram_prediction = False
if 'alert_sent_disk_prediction' not in st.session_state:
    st.session_state.alert_sent_disk_prediction = False
if 'dark_mode' not in st.session_state: # NEW: Dark mode state
    st.session_state.dark_mode = True # Default to dark mode

# --- Function to load and save config ---
def load_config():
    config_file_path = os.path.join(os.path.dirname(__file__), 'config.json')
    print(f"DEBUG: Looking for config.json at: {config_file_path}")

    default_config = {
        "thresholds": {
            "cpu_limit": 80,
            "ram_limit": 75,
            "disk_limit": 90
        },
        "alert_settings": {
            "line_webhook_url": "https://line-webhook-php.onrender.com",
            "line_target_user_id": "U4d66cb0a61bc7385dd2407080f64bb42"
        },
        "trend_analysis_settings": {
            "lookback_minutes": 5,
            "min_increase_percent": 10
        },
        "prediction_settings": {
            "prediction_lookback_minutes": 30,
            "prediction_alert_threshold_factor": 1.1,
            "prediction_model": "Linear Regression"
        }
    }

    config = {}
    config_updated = False

    try:
        if os.path.exists(config_file_path):
            with open(config_file_path, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
            print(f"DEBUG: ✅ Loaded configuration from {config_file_path}")
            
            config = default_config.copy()
            def update_dict(d, u):
                for k, v in u.items():
                    if isinstance(v, dict):
                        d[k] = update_dict(d.get(k, {}), v)
                    else:
                        d[k] = v
                return d
            
            initial_config_str = json.dumps(loaded_config, sort_keys=True)
            merged_config = update_dict(config, loaded_config)
            final_config_str = json.dumps(merged_config, sort_keys=True)

            if initial_config_str != final_config_str:
                config_updated = True
                config = merged_config
                print(f"DEBUG: Configuration merged with default values. Updates detected.")
            else:
                config = merged_config

        else:
            print(f"DEBUG: ❌ config.json not found. Creating with default values.")
            config = default_config
            config_updated = True

        if config_updated or not os.path.exists(config_file_path):
            with open(config_file_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            print(f"DEBUG: Configuration saved/updated to {config_file_path}")

    except json.JSONDecodeError as e:
        print(f"DEBUG: ❌ Error decoding config.json: {e}. Using default values and recreating file.")
        config = default_config
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"DEBUG: Recreated config.json with default values.")
    except Exception as e:
        print(f"DEBUG: ❌ An unexpected error occurred loading config.json: {e}. Using default values and recreating file.")
        config = default_config
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"DEBUG: Recreated config.json with default values due to unexpected error.")
    
    return config

def save_config(config_data):
    config_file_path = os.path.join(os.path.dirname(__file__), 'config.json')
    try:
        with open(config_file_path, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=2, ensure_ascii=False)
        print(f"DEBUG: ✅ Configuration saved to {config_file_path}")
        st.sidebar.success("Settings saved successfully!")
    except Exception as e:
        print(f"DEBUG: ❌ Error saving config.json: {e}")
        st.sidebar.error(f"Error saving settings: {e}")

# --- Function to save usage data to SQLite ---
def save_usage_to_db(timestamp, cpu, ram, disk, battery_percent):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO usage_data (timestamp, cpu, ram, disk, battery)
            VALUES (?, ?, ?, ?, ?)
        ''', (timestamp, cpu, ram, disk, battery_percent))
        conn.commit()
    except sqlite3.IntegrityError:
        print(f"DEBUG: Timestamp {timestamp} already exists in DB. Skipping insert.")
    except Exception as e:
        print(f"DEBUG: Error saving data to DB: {e}")
    finally:
        conn.close()

# --- Function to read usage data from SQLite for Trend Analysis and Prediction ---
def read_usage_data_from_db(lookback_period_minutes):
    conn = sqlite3.connect(DB_PATH)
    query_start_time = datetime.now() - timedelta(minutes=lookback_period_minutes)
    data = []
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT timestamp, cpu, ram, disk, battery FROM usage_data WHERE timestamp >= ? ORDER BY timestamp ASC", (query_start_time.strftime("%Y-%m-%d %H:%M:%S"),))
        rows = cursor.fetchall()
        for row in rows:
            data.append({
                'timestamp': datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S"),
                'cpu': row[1],
                'ram': row[2],
                'disk': row[3],
                'battery': row[4]
            })
    except Exception as e:
        print(f"DEBUG: Error reading data from DB for trend/prediction: {e}")
    finally:
        conn.close()
    return data

# --- Function to read ALL usage data from SQLite for Historical Chart and Analysis ---
def read_all_usage_data_from_db():
    conn = sqlite3.connect(DB_PATH)
    df = pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT timestamp, cpu, ram, disk, battery FROM usage_data ORDER BY timestamp ASC", conn)
        if not df.empty:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)
    except Exception as e:
        print(f"DEBUG: Error reading all usage data from DB: {e}")
        df = pd.DataFrame()
    finally:
        conn.close()
    return df

# --- Function to analyze trend ---
def analyze_trend(data_points, resource_name, min_increase_percent):
    if len(data_points) < 2:
        return None

    values = [dp[resource_name] for dp in data_points if isinstance(dp[resource_name], (int, float))]
    
    if not values or len(values) < 2:
        return None

    start_value = values[0]
    end_value = values[-1]

    if start_value == 0:
        if end_value > 0 and end_value > min_increase_percent:
            return f"({resource_name.upper()} usage significantly increased from 0% to {end_value:.1f}%)"
        return None
        
    increase_percentage = ((end_value - start_value) / start_value) * 100
    
    if increase_percentage >= min_increase_percent:
        return f"({resource_name.upper()} usage increased by {increase_percentage:.1f}% from {start_value:.1f}% to {end_value:.1f}%)"
    
    return None

# --- Function to train and predict using selected ML model ---
def train_and_predict(data_points, resource_name, model_type="Linear Regression"):
    if len(data_points) < 10: 
        return None, "Not enough data (min 10 points recommended)" 

    valid_data_points = []
    for dp in data_points:
        if isinstance(dp[resource_name], (int, float)):
            valid_data_points.append(dp)
    
    if len(valid_data_points) < 10:
        return None, "Not enough valid numeric data (min 10 points recommended)"

    time_series = pd.Series(
        [dp[resource_name] for dp in valid_data_points],
        index=[dp['timestamp'] for dp in valid_data_points]
    )

    prediction = None
    evaluation_metric = "N/A"

    try:
        if model_type == "Linear Regression":
            X = np.array(range(len(time_series))).reshape(-1, 1)
            y = time_series.values
            model = LinearRegression()
            model.fit(X, y)
            prediction = model.predict(np.array([[len(time_series)]]))[0]
            y_pred = model.predict(X)
            mse = mean_squared_error(y, y_pred)
            r2 = r2_score(y, y_pred)
            evaluation_metric = f"MSE: {mse:.2f}, R2: {r2:.2f}"
            
        elif model_type == "Random Forest":
            X = np.array(range(len(time_series))).reshape(-1, 1)
            y = time_series.values
            model = RandomForestRegressor(n_estimators=10, random_state=42)
            model.fit(X, y)
            prediction = model.predict(np.array([[len(time_series)]]))[0]
            y_pred = model.predict(X)
            mse = mean_squared_error(y, y_pred)
            r2 = r2_score(y, y_pred)
            evaluation_metric = f"MSE: {mse:.2f}, R2: {r2:.2f}"
            
        elif model_type == "ARIMA":
            if len(time_series) < 15 or time_series.var() == 0:
                return None, "Not enough data or no variance for ARIMA (min 15 points, non-zero variance recommended)"
            
            model = sm_arima.ARIMA(time_series, order=(1,1,0)) 
            model_fit = model.fit()
            prediction = model_fit.predict(start=len(time_series), end=len(time_series))[0]
            evaluation_metric = f"ARIMA AIC: {model_fit.aic:.2f}"
            
        else:
            return None, "Unknown Model Type"

        prediction = max(0.0, prediction)
        prediction = min(100.0, prediction)
        
        return prediction, evaluation_metric
    
    except Exception as e:
        print(f"DEBUG: Error training/predicting with {model_type}: {e}")
        return None, f"Error: {e}"

# Load config when app starts
config = load_config()

# Set Threshold and LINE Settings from config
CPU_LIMIT = config['thresholds']['cpu_limit']
RAM_LIMIT = config['thresholds']['ram_limit']
DISK_LIMIT = config['thresholds']['disk_limit']
LINE_WEBHOOK_URL = config['alert_settings']['line_webhook_url']
LINE_TARGET_USER_ID = config['alert_settings']['line_target_user_id']

# Trend Analysis Settings
LOOKBACK_MINUTES = config['trend_analysis_settings']['lookback_minutes']
MIN_INCREASE_PERCENT = config['trend_analysis_settings']['min_increase_percent']

# Prediction Analysis Settings
PREDICTION_LOOKBACK_MINUTES = config['prediction_settings']['prediction_lookback_minutes']
PREDICTION_ALERT_THRESHOLD_FACTOR = config['prediction_settings']['prediction_alert_threshold_factor']
PREDICTION_MODEL = config['prediction_settings']['prediction_model']

# --- UI section for settings in Sidebar ---
st.sidebar.header("⚙️ System Monitoring Settings")

# Dark Mode Toggle in Sidebar
dark_mode_checkbox = st.sidebar.checkbox("เปิดโหมดกลางคืน", value=st.session_state.dark_mode, key="dark_mode_toggle")
if dark_mode_checkbox != st.session_state.dark_mode:
    st.session_state.dark_mode = dark_mode_checkbox
    # Use JavaScript to toggle body class for theme
    js_code = f"""
    <script>
    if ({'true' if st.session_state.dark_mode else 'false'}) {{
        document.body.classList.remove('light-mode');
        document.body.classList.add('dark-mode');
    }} else {{
        document.body.classList.remove('dark-mode');
        document.body.classList.add('light-mode');
    }}
    applyThemeStyles(); // Call the script function to update CSS variables immediately
    </script>
    """
    st.markdown(js_code, unsafe_allow_html=True)
    st.rerun() # Rerun to apply changes, as st.session_state has changed

# Apply dynamic CSS class based on dark mode state
# These classes are used for the main container and individual card backgrounds
if st.session_state.dark_mode:
    current_container_class = "theme-container" # Use general theme class
    current_card_class = "theme-card" # Use general theme class
else:
    current_container_class = "theme-container"
    current_card_class = "theme-card"


with st.sidebar.form(key='threshold_form'):
    st.subheader("ตั้งค่าขีดจำกัด (%)")
    new_cpu_limit = st.slider("CPU Limit", 0, 100, CPU_LIMIT, key="cpu_slider")
    new_ram_limit = st.slider("RAM Limit", 0, 100, RAM_LIMIT, key="ram_slider")
    new_disk_limit = st.slider("Disk Limit", 0, 100, DISK_LIMIT, key="disk_slider")
    
    st.subheader("LINE Alert Settings")
    new_line_webhook_url = st.text_input("LINE Webhook URL", LINE_WEBHOOK_URL, key="webhook_input")
    new_line_target_user_id = st.text_input("LINE Target User ID", LINE_TARGET_USER_ID, key="userid_input")

    st.subheader("Trend Analysis Settings")
    new_lookback_minutes = st.slider("Lookback Minutes for Trend", 1, 60, LOOKBACK_MINUTES, key="lookback_slider")
    new_min_increase_percent = st.slider("Min Increase % for Trend Alert", 1, 100, MIN_INCREASE_PERCENT, key="min_increase_slider")

    st.subheader("Prediction Settings (ML)")
    new_prediction_lookback_minutes = st.slider("Prediction Lookback Minutes", 1, 60, PREDICTION_LOOKBACK_MINUTES, key="pred_lookback_slider")
    new_prediction_alert_threshold_factor = st.slider("Prediction Alert Factor (x Normal Limit)", 1.0, 2.0, PREDICTION_ALERT_THRESHOLD_FACTOR, step=0.05, key="pred_alert_factor_slider")
    
    new_prediction_model = st.selectbox(
        "เลือกโมเดลการทำนาย", 
        ("Linear Regression", "Random Forest", "ARIMA"), 
        index=["Linear Regression", "Random Forest", "ARIMA"].index(PREDICTION_MODEL),
        key="pred_model_selector"
    )

    submit_button = st.form_submit_button(label='บันทึกการตั้งค่า')

    if submit_button:
        config['thresholds']['cpu_limit'] = new_cpu_limit
        config['thresholds']['ram_limit'] = new_ram_limit
        config['thresholds']['disk_limit'] = new_disk_limit
        config['alert_settings']['line_webhook_url'] = new_line_webhook_url
        config['alert_settings']['line_target_user_id'] = new_line_target_user_id
        config['trend_analysis_settings']['lookback_minutes'] = new_lookback_minutes
        config['trend_analysis_settings']['min_increase_percent'] = new_min_increase_percent
        config['prediction_settings']['prediction_lookback_minutes'] = new_prediction_lookback_minutes
        config['prediction_settings']['prediction_alert_threshold_factor'] = new_prediction_alert_threshold_factor
        config['prediction_settings']['prediction_model'] = new_prediction_model 
        
        save_config(config)
        
        st.sidebar.info("โปรดรีสตาร์ทการ Monitoring (เอาเครื่องหมายออกแล้วติ๊กใหม่) หรือรันแอปใหม่เพื่อให้การตั้งค่ามีผลสมบูรณ์.")
        
        CPU_LIMIT = new_cpu_limit
        RAM_LIMIT = new_ram_limit
        DISK_LIMIT = new_disk_limit
        LINE_WEBHOOK_URL = new_line_webhook_url
        LINE_TARGET_USER_ID = new_line_target_user_id
        LOOKBACK_MINUTES = new_lookback_minutes
        MIN_INCREASE_PERCENT = new_min_increase_percent
        PREDICTION_LOOKBACK_MINUTES = new_prediction_lookback_minutes
        PREDICTION_ALERT_THRESHOLD_FACTOR = new_prediction_alert_threshold_factor
        PREDICTION_MODEL = new_prediction_model


# --- Main display section ---
# Use a spinner while the main loop runs
with st.spinner('กำลังโหลดข้อมูลและประมวลผล...'):
    # Wrap main content in a container with dynamic class for theme
    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True) # Removed rounded-xl shadow-lg here as it's now in .theme-container

    st.subheader("ภาพรวมการใช้งานปัจจุบัน")
    current_usage_cols = st.columns(4)

    # Placeholders for metrics. The actual metric will be updated inside the loop
    cpu_metric_placeholder = current_usage_cols[0].empty()
    ram_metric_placeholder = current_usage_cols[1].empty()
    disk_metric_placeholder = current_usage_cols[2].empty()
    battery_metric_placeholder = current_usage_cols[3].empty()

    st.markdown("</div>", unsafe_allow_html=True) # Close the first container

    # Wrap the next section in a new container
    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True)
    st.subheader("กราฟการใช้งานปัจจุบัน (30 วินาทีล่าสุด)")
    realtime_chart_placeholder = st.empty()
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True)
    st.subheader("กราฟประวัติการใช้งาน")
    historical_chart_placeholder = st.empty()
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True)
    st.subheader("การคาดการณ์การใช้งาน (จาก Machine Learning)")
    prediction_cols = st.columns(3)
    prediction_eval_cols = st.columns(3) # This will hold the evaluation captions
    st.markdown("</div>", unsafe_allow_html=True)


    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True)
    st.subheader("การวิเคราะห์ข้อมูลเชิงลึก (จาก Log File)")
    analysis_metric_cols = st.columns(3)
    analysis_detail_cols = st.columns(3)
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown(f'<div class="{current_container_class} p-6">', unsafe_allow_html=True)
    st.subheader("ประวัติการแจ้งเตือน")
    alert_history_placeholder = st.empty() # Placeholder for alert history text_area

    # Clear Alert History Button
    clear_button_col, _ = st.columns([0.2, 0.8])
    with clear_button_col:
        if st.button("ล้างประวัติการแจ้งเตือน"):
            st.session_state.alert_log = []
            st.info("ประวัติการแจ้งเตือนถูกล้างแล้ว.")
            alert_history_placeholder.text_area("Alert History", "", height=200, key=f"alert_history_textarea_cleared_{datetime.now()}")
    st.markdown("</div>", unsafe_allow_html=True) # Close the last container


    monitoring = st.checkbox("เริ่ม Monitoring", value=True)

    if not monitoring:
        st.info(f"Monitoring is off. Current limits: CPU={CPU_LIMIT}%, RAM={RAM_LIMIT}%, Disk={DISK_LIMIT}%")

    while monitoring:
        current_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cpu = psutil.cpu_percent(interval=1) 
        ram = psutil.virtual_memory().percent
        disk = psutil.disk_usage('/').percent
        battery = psutil.sensors_battery()
        battery_percent = battery.percent if battery else "N/A"

        # Save current usage data to SQLite DB
        save_usage_to_db(current_timestamp, cpu, ram, disk, battery_percent)

        # Update current usage metrics within their columns/cards
        cpu_metric_placeholder.metric("🖥️ CPU (%)", f"{cpu:.1f}%")
        ram_metric_placeholder.metric("🧠 RAM (%)", f"{ram:.1f}%")
        disk_metric_placeholder.metric("💽 Disk (%)", f"{disk:.1f}%")
        battery_metric_placeholder.metric("🔋 Battery (%)", f"{battery_percent}%")

        if 'realtime_cpu_data' not in st.session_state:
            st.session_state.realtime_cpu_data = []
            st.session_state.realtime_ram_data = []
            st.session_state.realtime_disk_data = []
            st.session_state.realtime_labels = []

        st.session_state.realtime_cpu_data.append(cpu)
        st.session_state.realtime_ram_data.append(ram)
        st.session_state.realtime_disk_data.append(disk)
        st.session_state.realtime_labels.append(datetime.now().strftime("%H:%M:%S"))

        MAX_REALTIME_POINTS = 30
        if len(st.session_state.realtime_labels) > MAX_REALTIME_POINTS:
            st.session_state.realtime_labels.pop(0)
            st.session_state.realtime_cpu_data.pop(0)
            st.session_state.realtime_ram_data.pop(0)
            st.session_state.realtime_disk_data.pop(0)
        
        realtime_chart_data = pd.DataFrame({
            'Time': st.session_state.realtime_labels,
            'CPU': st.session_state.realtime_cpu_data,
            'RAM': st.session_state.realtime_ram_data,
            'Disk': st.session_state.realtime_disk_data
        }).set_index('Time')
        realtime_chart_placeholder.line_chart(realtime_chart_data)


        # Read historical data from SQLite DB
        historical_df = read_all_usage_data_from_db()
        if not historical_df.empty:
            historical_df_numeric = historical_df[['cpu', 'ram', 'disk']]
            historical_chart_placeholder.line_chart(historical_df_numeric)

            # Data Analysis Section - Averages
            analysis_metric_cols[0].metric("CPU เฉลี่ย", f"{historical_df['cpu'].mean():.1f}%")
            analysis_metric_cols[1].metric("RAM เฉลี่ย", f"{historical_df['ram'].mean():.1f}%")
            analysis_metric_cols[2].metric("Disk เฉลี่ย", f"{historical_df['disk'].mean():.1f}%")

            # Data Analysis Section - Min/Max/Std Dev
            analysis_detail_cols[0].caption(f"**CPU Min:** {historical_df['cpu'].min():.1f}%")
            analysis_detail_cols[0].caption(f"**CPU Max:** {historical_df['cpu'].max():.1f}%")
            analysis_detail_cols[0].caption(f"**CPU Std Dev:** {historical_df['cpu'].std():.1f}%")

            analysis_detail_cols[1].caption(f"**RAM Min:** {historical_df['ram'].min():.1f}%")
            analysis_detail_cols[1].caption(f"**RAM Max:** {historical_df['ram'].max():.1f}%")
            analysis_detail_cols[1].caption(f"**RAM Std Dev:** {historical_df['ram'].std():.1f}%")

            analysis_detail_cols[2].caption(f"**Disk Min:** {historical_df['disk'].min():.1f}%")
            analysis_detail_cols[2].caption(f"**Disk Max:** {historical_df['disk'].max():.1f}%")
            analysis_detail_cols[2].caption(f"**Disk Std Dev:** {historical_df['disk'].std():.1f}%")


        else:
            historical_chart_placeholder.info("No historical data available yet. Please wait for data collection.")
            analysis_metric_cols[0].info("CPU เฉลี่ย: ไม่มีข้อมูล")
            analysis_metric_cols[1].info("RAM เฉลี่ย: ไม่มีข้อมูล")
            analysis_metric_cols[2].info("Disk เฉลี่ย: ไม่มีข้อมูล")
            analysis_detail_cols[0].caption("CPU Min/Max/Std: N/A")
            analysis_detail_cols[1].caption("RAM Min/Max/Std: N/A")
            analysis_detail_cols[2].caption("Disk Min/Max/Std: N/A")


        # --- Perform Predictions and Display ---
        predicted_cpu, eval_cpu = None, None
        predicted_ram, eval_ram = None, None
        predicted_disk, eval_disk = None, None

        # Get recent data for prediction
        recent_data_for_prediction = read_usage_data_from_db(PREDICTION_LOOKBACK_MINUTES)

        if len(recent_data_for_prediction) >= (15 if PREDICTION_MODEL == "ARIMA" else 10): 
            predicted_cpu, eval_cpu = train_and_predict(recent_data_for_prediction, 'cpu', PREDICTION_MODEL)
            predicted_ram, eval_ram = train_and_predict(recent_data_for_prediction, 'ram', PREDICTION_MODEL)
            predicted_disk, eval_disk = train_and_predict(recent_data_for_prediction, 'disk', PREDICTION_MODEL)

        prediction_cols[0].metric("🖥️ CPU (คาดการณ์)", f"{predicted_cpu:.1f}%" if predicted_cpu is not None else "N/A")
        prediction_eval_cols[0].caption(f"Eval: {eval_cpu}" if predicted_cpu is not None else "Eval: N/A")

        prediction_cols[1].metric("🧠 RAM (คาดการณ์)", f"{predicted_ram:.1f}%" if predicted_ram is not None else "N/A")
        prediction_eval_cols[1].caption(f"Eval: {eval_ram}" if predicted_ram is not None else "Eval: N/A")

        prediction_cols[2].metric("💽 Disk (คาดการณ์)", f"{predicted_disk:.1f}%" if predicted_disk is not None else "N/A")
        prediction_eval_cols[2].caption(f"Eval: {eval_disk}" if predicted_disk is not None else "Eval: N/A")


        # --- Section for detecting and sending LINE alerts ---
        current_alert_messages = []

        # Threshold Alerts
        if cpu > CPU_LIMIT:
            if not st.session_state.alert_sent_cpu_threshold:
                current_alert_messages.append(f"🖥️ CPU usage is high: {cpu:.1f}% (Limit: {CPU_LIMIT}%)")
                st.session_state.alert_sent_cpu_threshold = True
        else:
            st.session_state.alert_sent_cpu_threshold = False

        if ram > RAM_LIMIT:
            if not st.session_state.alert_sent_ram_threshold:
                current_alert_messages.append(f"🧠 RAM usage is high: {ram:.1f}% (Limit: {RAM_LIMIT}%)")
                st.session_state.alert_sent_ram_threshold = True
        else:
            st.session_state.alert_sent_ram_threshold = False

        if disk > DISK_LIMIT:
            if not st.session_state.alert_sent_disk_threshold:
                current_alert_messages.append(f"💽 Disk usage is high: {disk:.1f}% (Limit: {DISK_LIMIT}%)")
                st.session_state.alert_sent_disk_threshold = True
        else:
            st.session_state.alert_sent_disk_threshold = False

        # Trend Alerts
        recent_data_for_trend = read_usage_data_from_db(LOOKBACK_MINUTES)
        
        cpu_trend_alert = analyze_trend(recent_data_for_trend, 'cpu', MIN_INCREASE_PERCENT)
        if cpu_trend_alert and not st.session_state.alert_sent_cpu_trend:
            current_alert_messages.append(f"📈 CPU usage trend detected {cpu_trend_alert}")
            st.session_state.alert_sent_cpu_trend = True
        elif not cpu_trend_alert:
            st.session_state.alert_sent_cpu_trend = False

        ram_trend_alert = analyze_trend(recent_data_for_trend, 'ram', MIN_INCREASE_PERCENT)
        if ram_trend_alert and not st.session_state.alert_sent_ram_trend:
            current_alert_messages.append(f"📈 RAM usage trend detected {ram_trend_alert}")
            st.session_state.alert_sent_ram_trend = True
        elif not ram_trend_alert:
            st.session_state.alert_sent_ram_trend = False

        disk_trend_alert = analyze_trend(recent_data_for_trend, 'disk', MIN_INCREASE_PERCENT)
        if disk_trend_alert and not st.session_state.alert_sent_disk_trend:
            current_alert_messages.append(f"📈 Disk usage trend detected {disk_trend_alert}")
            st.session_state.alert_sent_disk_trend = True
        elif not disk_trend_alert:
            st.session_state.alert_sent_disk_trend = False

        # Prediction Alerts
        if predicted_cpu is not None:
            prediction_alert_cpu_limit = CPU_LIMIT * PREDICTION_ALERT_THRESHOLD_FACTOR
            if predicted_cpu > prediction_alert_cpu_limit:
                if not st.session_state.alert_sent_cpu_prediction:
                    current_alert_messages.append(f"🔮 CPU (ML) คาดการณ์สูง: {predicted_cpu:.1f}% (เกิน {prediction_alert_cpu_limit:.1f}%)")
                    st.session_state.alert_sent_cpu_prediction = True
            else:
                st.session_state.alert_sent_cpu_prediction = False

        if predicted_ram is not None:
            prediction_alert_ram_limit = RAM_LIMIT * PREDICTION_ALERT_THRESHOLD_FACTOR
            if predicted_ram > prediction_alert_ram_limit:
                if not st.session_state.alert_sent_ram_prediction:
                    current_alert_messages.append(f"🔮 RAM (ML) คาดการณ์สูง: {predicted_ram:.1f}% (เกิน {prediction_alert_ram_limit:.1f}%)")
                    st.session_state.alert_sent_ram_prediction = True
            else:
                st.session_state.alert_sent_ram_prediction = False

        if predicted_disk is not None:
            prediction_alert_disk_limit = DISK_LIMIT * PREDICTION_ALERT_THRESHOLD_FACTOR
            if predicted_disk > prediction_alert_disk_limit:
                if not st.session_state.alert_sent_disk_prediction:
                    current_alert_messages.append(f"🔮 Disk (ML) คาดการณ์สูง: {predicted_disk:.1f}% (เกิน {prediction_alert_disk_limit:.1f}%)")
                    st.session_state.alert_sent_disk_prediction = True
            else:
                st.session_state.alert_sent_disk_prediction = False


        if current_alert_messages:
            full_alert_message = f"🚨 PreBreak Alert ({current_timestamp}):\n" + "\n".join(current_alert_messages)

            st.session_state.alert_log.append(f"[{current_timestamp}] {full_alert_message}")
            st.session_state.alert_log = st.session_state.alert_log[-10:] 

            payload = {
                "message": full_alert_message,
                "userId": LINE_TARGET_USER_ID
            }
            headers = {'Content-Type': 'application/json'}

            try:
                response = requests.post(LINE_WEBHOOK_URL, data=json.dumps(payload), headers=headers)
                response.raise_for_status()
                print(f"[{current_timestamp}] Alert sent to LINE: {full_alert_message}")
            except requests.exceptions.RequestException as e:
                print(f"[{current_timestamp}] Error sending alert to LINE: {e}")
        
        alert_log_display_text = "\n".join(reversed(st.session_state.alert_log))
        alert_history_placeholder.text_area("Alert History", alert_log_display_text, height=200, key=f"alert_history_textarea_{current_timestamp}")

        time.sleep(2)

        if not monitoring:
            st.stop()
